﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MissionSite.Controllers
{
    public class MissionaryController : Controller
    {
        // GET: Missionary
        public ActionResult Index(string mission, string missionPresName, string missionAddress, string language, string climate, string dominateReligion, string missionFlag, string activepage)
        {
            @ViewBag.mission = mission;
            @ViewBag.missionPresName = missionPresName;
            @ViewBag.missionAddress = missionAddress;
            @ViewBag.language = language;
            @ViewBag.climate = climate;
            @ViewBag.dominateReligion = dominateReligion;
            @ViewBag.missionFlag = missionFlag;

            @ViewBag.activepage = activepage;

            return View();
        }

    }
}